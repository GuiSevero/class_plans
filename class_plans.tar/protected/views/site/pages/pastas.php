<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - Pastas';
$this->breadcrumbs=array(
	'Pastas',
);
?>
<h1>Pastas</h1>

<p>Nesta sessão você poderá definir pastas que contenham diversos planos de aula.</p>
