<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - Planos de Aula';
$this->breadcrumbs=array(
	'Planos de Aula',
);
?>
<h1>Planos de Aula</h1>

<p>Nesta sessão você poderá acessar todos os planos de aula disponíveis</p>
